#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd


# In[1]:


def validate(timeSeries):
    prevClose = -1
    improvementList = {}
    for date,close in timeSeries.items():
        #use newClose and newDate as float and int values respectively
        newDate = int(date)
        if (',' in close):
            newClose = close.replace(',','')
            newClose = float(newClose)
        else:
            newClose = float(close)
            
        #if there was a row/date that came before the current stock, prepare it
        #otherwise, move to the next date, although this normally signifies the end of the series
        if ((newDate-1) in timeSeries.index):
            prevClose = timeSeries[newDate-1]
            if (',' in prevClose):
                prevClose = prevClose.replace(',','')
            prevClose = float(prevClose)
        else:
            continue
           
        #calculates the percent gain from the first day to the second, then stores in improvementList
        improvementList[newDate] = (newClose - prevClose)/prevClose
    return improvementList

