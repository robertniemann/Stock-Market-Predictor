#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd
import numpy as np


# In[ ]:


#simple concept, just goes through and compares whether each item from the second series is greater
#than the corresponding item from the first series. returns the series of all items that had corresponding
#pairs, and whether or not the item from the second series exceeded the item from the first.
def compare(snpSeries, targetSeries):
    betterTargetImprovement = {}
    for date,close in snpSeries.items():
        #if there is no corresponding date, skip
        if not (date in targetSeries):
            continue
        #if there is a corresponding date, compare and record in boolean
        if (close > targetSeries[date]):
            betterTargetImprovement[date-1] = False
        else:
            betterTargetImprovement[date-1] = True
    return pd.DataFrame.from_dict(betterTargetImprovement, orient='index')

